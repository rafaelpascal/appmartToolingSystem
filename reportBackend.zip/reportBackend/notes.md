#INDEX.JS = This is the entry file where all the modules are imported and routes created
CONTROLLER FOLDER
#auth.js (controller) = is the controller for creating User, login and change password
#category.js (controller) = this is the controller for creating Category
#logs.js = this is the controller for creating LOGS
#remarks.js = this is the controller for leaving a comment on a report
#reply.js = this is the controller for replying to a comment on a report